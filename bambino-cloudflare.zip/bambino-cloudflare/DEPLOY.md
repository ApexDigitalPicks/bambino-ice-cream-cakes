# Deploying Bambino Ice Cream Cakes to Cloudflare

This folder is ready to go live as its own standalone site on Cloudflare
(Workers with static assets — the current recommended way to host a static
site on Cloudflare, replacing the old "Pages" product for new projects).

**Correction:** Cloudflare's dashboard no longer offers a plain drag-and-drop
"upload a local folder" option. The **Create application** flow only offers
templates or a connected **Git repository**. So the two real no-guesswork
paths are:

## Option A — GitHub + Cloudflare Git integration (no CLI, browser only)

1. Create a new GitHub repo (e.g. `bambino-ice-cream-cakes`), public or private.
2. Add `public/index.html` from this package to it — GitHub's web editor
   ("Add file → Create new file", paste the content in) works without any
   local git install.
3. In the Cloudflare dashboard → **Workers & Pages** → **Create application**
   → **Import an existing Git repository** → authorize GitHub → select the repo.
4. Build settings: no build command, output directory `public`.
5. **Deploy**. Cloudflare gives you a `bambino-ice-cream-cakes.<subdomain>.workers.dev`
   URL immediately. Add your own domain after under
   **Settings → Domains & Routes → Add custom domain**.

## Option B — CLI (same pattern you used for Proper Lekker)

From this folder:

```bash
npm install -g wrangler   # if not already installed
wrangler login            # opens browser, connects your Cloudflare account
wrangler deploy
```

Wrangler reads `wrangler.jsonc` (already set up here) and deploys the
`public/` folder directly — no GitHub needed for this path. Add a custom
domain the same way as in Option A, or with:

```bash
wrangler deploy --routes bambinoicecreamcakes.co.za/*
```
(requires the domain's DNS to already be on Cloudflare)

## Why I can't push this live myself

Claude's Cloudflare connector in this chat only has read/management access
to Workers, D1, KV, R2, and Hyperdrive metadata — there's no "create/deploy a
Worker" function exposed to it, and this sandbox has no outbound internet
access to run `wrangler` directly. Claude in Chrome can drive Option A end
to end in your own browser session (it's a separate extension you run
yourself, not something I can trigger from this chat). Claude Code has real
CLI + network access and can run Option B's commands on your machine.
